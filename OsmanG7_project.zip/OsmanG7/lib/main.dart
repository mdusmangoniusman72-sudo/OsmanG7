// OsmanG7 - lib/main.dart
//
// pubspec.yaml dependencies:
//   webview_flutter: ^4.9.0
//   path_provider: ^2.1.4
//   permission_handler: ^11.3.1
//   http: ^1.2.2
//   local_auth: ^2.3.0
//   crypto: ^3.0.5
//   file_picker: ^8.1.2
//
// android/app/src/main/AndroidManifest.xml (inside <manifest>):
//   <uses-permission android:name="android.permission.INTERNET"/>
//   <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
//   <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
//   <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>
//   <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
//   <uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
//   <uses-permission android:name="android.permission.USE_BIOMETRIC"/>
//   and on <application>: android:requestLegacyExternalStorage="true"
//
// android/app/build.gradle: minSdkVersion 24
// MainActivity.kt must extend FlutterFragmentActivity (required by local_auth).

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:local_auth/local_auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:webview_flutter/webview_flutter.dart';

// ─────────────────────────────── Constants ───────────────────────────────

const String kBrand = 'OsmanG7';
const Color kAccent = Color(0xFF7C4DFF);
const Color kSurface = Color(0xFF181820);
const Color kBackground = Color(0xFF0E0E12);
const String kInternalRoot = '/storage/emulated/0';

/// Social platforms (YouTube/Facebook/TikTok) do not expose direct media
/// links. Point this at your own resolver backend that accepts
/// POST {"url": "...", "format": "mp3|mp4"} and returns {"url": "<direct>"}.
/// Leave empty to allow direct media links only.
const String kResolverEndpoint = '';

const Set<String> kAudioExts = {'mp3', 'm4a', 'aac', 'ogg', 'wav'};
const Set<String> kVideoExts = {'mp4', 'webm', 'mkv', '3gp', 'mov'};

// ─────────────────────────────── Bootstrap ───────────────────────────────

void main() {
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (details) {
      FlutterError.presentError(details);
      debugPrint('FlutterError: ${details.exceptionAsString()}');
    };
    runApp(const OsmanG7App());
  }, (error, stack) {
    debugPrint('Unhandled error: $error');
  });
}

class OsmanG7App extends StatelessWidget {
  const OsmanG7App({super.key});

  @override
  Widget build(BuildContext context) {
    final base = ThemeData.dark(useMaterial3: true);
    return MaterialApp(
      title: kBrand,
      debugShowCheckedModeBanner: false,
      theme: base.copyWith(
        scaffoldBackgroundColor: kBackground,
        colorScheme: base.colorScheme.copyWith(
          primary: kAccent,
          secondary: kAccent,
          surface: kSurface,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: kBackground,
          elevation: 0,
          centerTitle: false,
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: kSurface,
          indicatorColor: kAccent.withAlpha(70),
          labelTextStyle: WidgetStateProperty.all(
            const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: kSurface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const HomeShell(),
    );
  }
}

// ─────────────────────────────── Shared helpers ──────────────────────────

void toast(BuildContext context, String message) {
  if (!context.mounted) return;
  final messenger = ScaffoldMessenger.maybeOf(context);
  messenger?.hideCurrentSnackBar();
  messenger?.showSnackBar(
    SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
  );
}

String formatBytes(int bytes) {
  if (bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  final i = min((log(bytes) / log(1024)).floor(), units.length - 1);
  final value = bytes / pow(1024, i);
  return '${value.toStringAsFixed(i == 0 ? 0 : 1)} ${units[i]}';
}

String fileName(String path) => path.split('/').last;

String? extOf(String path) {
  final name = fileName(path);
  final dot = name.lastIndexOf('.');
  if (dot <= 0 || dot == name.length - 1) return null;
  return name.substring(dot + 1).toLowerCase();
}

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: kSurface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0x1AFFFFFF)),
          ),
          child: child,
        ),
      ),
    );
  }
}

Future<bool> requestStoragePermission() async {
  if (!Platform.isAndroid) return true;
  try {
    if (await Permission.manageExternalStorage.isGranted) return true;
    final manage = await Permission.manageExternalStorage.request();
    if (manage.isGranted) return true;
    final storage = await Permission.storage.request();
    if (storage.isGranted) return true;
    final media = await [Permission.photos, Permission.videos].request();
    return media.values.any((s) => s.isGranted);
  } catch (e) {
    debugPrint('Permission error: $e');
    return false;
  }
}

class AppPaths {
  /// Returns the public /OsmanG7 folder, or an app-scoped fallback.
  static Future<Directory> downloadDir() async {
    try {
      final dir = Directory('$kInternalRoot/$kBrand');
      if (!await dir.exists()) await dir.create(recursive: true);
      final probe = File('${dir.path}/.probe');
      await probe.writeAsString('ok', flush: true);
      await probe.delete();
      return dir;
    } catch (_) {
      Directory base;
      try {
        base = await getExternalStorageDirectory() ??
            await getApplicationDocumentsDirectory();
      } catch (_) {
        base = await getApplicationDocumentsDirectory();
      }
      final fallback = Directory('${base.path}/$kBrand');
      if (!await fallback.exists()) await fallback.create(recursive: true);
      return fallback;
    }
  }
}

class DiskInfo {
  final int total;
  final int used;
  final int free;
  const DiskInfo(this.total, this.used, this.free);
  double get usedRatio => total <= 0 ? 0 : (used / total).clamp(0.0, 1.0);
}

Future<DiskInfo?> readDisk(String path) async {
  try {
    final result = await Process.run('df', ['-k', path]);
    if (result.exitCode != 0) return null;
    final lines = (result.stdout as String)
        .trim()
        .split('\n')
        .where((l) => l.trim().isNotEmpty)
        .toList();
    if (lines.length < 2) return null;
    final parts = lines.last.trim().split(RegExp(r'\s+'));
    if (parts.length < 4) return null;
    final total = int.parse(parts[1]) * 1024;
    final used = int.parse(parts[2]) * 1024;
    final free = int.parse(parts[3]) * 1024;
    return DiskInfo(total, used, free);
  } catch (e) {
    debugPrint('readDisk error: $e');
    return null;
  }
}

Future<List<File>> scanFiles(
  List<String> roots,
  Set<String> exts, {
  int cap = 3000,
}) async {
  final found = <File>[];
  final stack = roots.map((r) => Directory(r)).toList();
  while (stack.isNotEmpty && found.length < cap) {
    final dir = stack.removeLast();
    try {
      await for (final entity in dir.list(followLinks: false)) {
        final name = fileName(entity.path);
        if (name.startsWith('.')) continue;
        if (entity is Directory) {
          if (entity.path.endsWith('/Android')) continue;
          stack.add(entity);
        } else if (entity is File) {
          final ext = extOf(entity.path);
          if (ext != null && exts.contains(ext)) {
            found.add(entity);
            if (found.length >= cap) break;
          }
        }
      }
    } catch (_) {
      // Unreadable directory: skip.
    }
  }
  final stamps = <String, int>{};
  for (final f in found) {
    try {
      stamps[f.path] = f.lastModifiedSync().millisecondsSinceEpoch;
    } catch (_) {
      stamps[f.path] = 0;
    }
  }
  found.sort((a, b) => (stamps[b.path] ?? 0).compareTo(stamps[a.path] ?? 0));
  return found;
}

// ─────────────────────────────── Home shell ──────────────────────────────

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final ValueNotifier<String> _sharedLink = ValueNotifier<String>('');
  final GlobalKey<VaultTabState> _vaultKey = GlobalKey<VaultTabState>();

  static const _titles = [
    'Storage',
    'Media Browser',
    'Downloader',
    'Security Vault',
  ];

  void _select(int i) {
    if (_index == 3 && i != 3) _vaultKey.currentState?.lock();
    setState(() => _index = i);
  }

  void _sendToDownloader(String url) {
    _sharedLink.value = url;
    _select(2);
  }

  @override
  void dispose() {
    _sharedLink.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.shield_moon, color: kAccent),
            const SizedBox(width: 10),
            Text(
              '$kBrand · ${_titles[_index]}',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
      body: IndexedStack(
        index: _index,
        children: [
          const StorageTab(),
          BrowserTab(onSendToDownloader: _sendToDownloader),
          DownloaderTab(sharedLink: _sharedLink),
          VaultTab(key: _vaultKey),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: _select,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.pie_chart_outline),
            selectedIcon: Icon(Icons.pie_chart),
            label: 'Storage',
          ),
          NavigationDestination(
            icon: Icon(Icons.public_outlined),
            selectedIcon: Icon(Icons.public),
            label: 'Browser',
          ),
          NavigationDestination(
            icon: Icon(Icons.download_outlined),
            selectedIcon: Icon(Icons.download),
            label: 'Downloader',
          ),
          NavigationDestination(
            icon: Icon(Icons.lock_outline),
            selectedIcon: Icon(Icons.lock),
            label: 'Vault',
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────── Tab 1: Storage ──────────────────────────

enum MediaKind { photos, videos, documents }

const Map<MediaKind, Set<String>> kKindExts = {
  MediaKind.photos: {'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic'},
  MediaKind.videos: {'mp4', 'mkv', 'webm', '3gp', 'avi', 'mov'},
  MediaKind.documents: {
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'epub',
  },
};

class StorageTab extends StatefulWidget {
  const StorageTab({super.key});

  @override
  State<StorageTab> createState() => _StorageTabState();
}

class _StorageTabState extends State<StorageTab> {
  DiskInfo? _internal;
  DiskInfo? _sd;
  String? _sdRoot;
  bool _loading = true;
  bool _granted = false;

  List<String> get _roots => [kInternalRoot, if (_sdRoot != null) _sdRoot!];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    final granted = await requestStoragePermission();
    DiskInfo? internal;
    DiskInfo? sd;
    String? sdRoot;
    try {
      internal = await readDisk(kInternalRoot);
    } catch (_) {}
    try {
      final dirs = await getExternalStorageDirectories();
      if (dirs != null && dirs.length > 1) {
        final p = dirs[1].path;
        final idx = p.indexOf('/Android');
        if (idx > 0) {
          sdRoot = p.substring(0, idx);
          sd = await readDisk(sdRoot);
        }
      }
    } catch (e) {
      debugPrint('SD detection error: $e');
    }
    if (!mounted) return;
    setState(() {
      _granted = granted;
      _internal = internal;
      _sd = sd;
      _sdRoot = sdRoot;
      _loading = false;
    });
  }

  void _open(MediaKind kind) {
    if (!_granted) {
      toast(context, 'Grant storage access first');
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => MediaListPage(kind: kind, roots: _roots),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          if (!_loading && !_granted) ...[
            AppCard(
              child: Row(
                children: [
                  const Icon(Icons.warning_amber, color: Colors.amber),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text('Storage permission is required to browse files.'),
                  ),
                  TextButton(
                    onPressed: () async {
                      await openAppSettings();
                    },
                    child: const Text('Settings'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
          _DiskCard(
            title: 'Device Internal Storage',
            icon: Icons.smartphone,
            info: _internal,
            loading: _loading,
          ),
          const SizedBox(height: 12),
          _DiskCard(
            title: 'SD Card',
            icon: Icons.sd_card,
            info: _sd,
            loading: _loading,
            emptyText: 'No SD card detected',
          ),
          const SizedBox(height: 20),
          const Text(
            'Local files',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _KindTile(
                icon: Icons.photo_library,
                label: 'Photos',
                onTap: () => _open(MediaKind.photos),
              ),
              const SizedBox(width: 10),
              _KindTile(
                icon: Icons.video_library,
                label: 'Videos',
                onTap: () => _open(MediaKind.videos),
              ),
              const SizedBox(width: 10),
              _KindTile(
                icon: Icons.description,
                label: 'Documents',
                onTap: () => _open(MediaKind.documents),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DiskCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final DiskInfo? info;
  final bool loading;
  final String emptyText;

  const _DiskCard({
    required this.title,
    required this.icon,
    required this.info,
    required this.loading,
    this.emptyText = 'Storage info unavailable',
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: kAccent),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          if (loading)
            const LinearProgressIndicator()
          else if (info == null)
            Text(emptyText, style: const TextStyle(color: Colors.white54))
          else ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: info!.usedRatio,
                minHeight: 10,
                backgroundColor: const Color(0x22FFFFFF),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Used: ${formatBytes(info!.used)}'),
                Text('Free: ${formatBytes(info!.free)}'),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'Total: ${formatBytes(info!.total)}',
              style: const TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ],
      ),
    );
  }
}

class _KindTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _KindTile({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: AppCard(
        onTap: onTap,
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          children: [
            Icon(icon, size: 30, color: kAccent),
            const SizedBox(height: 8),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class MediaListPage extends StatefulWidget {
  final MediaKind kind;
  final List<String> roots;

  const MediaListPage({super.key, required this.kind, required this.roots});

  @override
  State<MediaListPage> createState() => _MediaListPageState();
}

class _MediaListPageState extends State<MediaListPage> {
  List<File> _files = [];
  bool _loading = true;

  String get _title {
    switch (widget.kind) {
      case MediaKind.photos:
        return 'Photos';
      case MediaKind.videos:
        return 'Videos';
      case MediaKind.documents:
        return 'Documents';
    }
  }

  @override
  void initState() {
    super.initState();
    _scan();
  }

  Future<void> _scan() async {
    try {
      final files = await scanFiles(widget.roots, kKindExts[widget.kind]!);
      if (!mounted) return;
      setState(() {
        _files = files;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      toast(context, 'Scan failed: $e');
    }
  }

  Future<void> _delete(File f) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete file?'),
        content: Text(fileName(f.path)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await f.delete();
      if (!mounted) return;
      setState(() => _files.remove(f));
    } catch (e) {
      if (mounted) toast(context, 'Could not delete: $e');
    }
  }

  void _details(File f) {
    int size = 0;
    DateTime? modified;
    try {
      size = f.lengthSync();
      modified = f.lastModifiedSync();
    } catch (_) {}
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(fileName(f.path)),
        content: SelectableText(
          'Path: ${f.path}\nSize: ${formatBytes(size)}\n'
          'Modified: ${modified?.toLocal().toString().split('.').first ?? '-'}',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: f.path));
              Navigator.pop(ctx);
              toast(context, 'Path copied');
            },
            child: const Text('Copy path'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('$_title (${_files.length})')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _files.isEmpty
              ? Center(child: Text('No ${_title.toLowerCase()} found'))
              : widget.kind == MediaKind.photos
                  ? _buildGrid()
                  : _buildList(),
    );
  }

  Widget _buildGrid() {
    return GridView.builder(
      padding: const EdgeInsets.all(8),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 6,
        crossAxisSpacing: 6,
      ),
      itemCount: _files.length,
      itemBuilder: (_, i) {
        final f = _files[i];
        return GestureDetector(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => _PhotoViewer(file: f)),
          ),
          onLongPress: () => _delete(f),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(
              f,
              fit: BoxFit.cover,
              cacheWidth: 300,
              errorBuilder: (_, __, ___) => const ColoredBox(
                color: Color(0xFF222222),
                child: Icon(Icons.broken_image),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildList() {
    final isVideo = widget.kind == MediaKind.videos;
    return ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: _files.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) {
        final f = _files[i];
        int size = 0;
        try {
          size = f.lengthSync();
        } catch (_) {}
        return AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          onTap: () => _details(f),
          child: Row(
            children: [
              Icon(isVideo ? Icons.movie : Icons.insert_drive_file,
                  color: kAccent),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(fileName(f.path),
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                    Text(formatBytes(size),
                        style: const TextStyle(
                            color: Colors.white54, fontSize: 12)),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () => _delete(f),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _PhotoViewer extends StatelessWidget {
  final File file;
  const _PhotoViewer({required this.file});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(fileName(file.path), style: const TextStyle(fontSize: 14)),
      ),
      body: Center(
        child: InteractiveViewer(
          maxScale: 6,
          child: Image.file(
            file,
            errorBuilder: (_, __, ___) =>
                const Icon(Icons.broken_image, size: 64),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────── Tab 2: Media Browser ────────────────────

class BrowserTab extends StatefulWidget {
  final ValueChanged<String> onSendToDownloader;
  const BrowserTab({super.key, required this.onSendToDownloader});

  @override
  State<BrowserTab> createState() => _BrowserTabState();
}

class _BrowserTabState extends State<BrowserTab>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TabBar(
          controller: _tabs,
          indicatorColor: kAccent,
          tabs: const [
            Tab(icon: Icon(Icons.smart_display), text: 'YouTube'),
            Tab(icon: Icon(Icons.facebook), text: 'Facebook'),
            Tab(icon: Icon(Icons.music_note), text: 'TikTok'),
          ],
        ),
        Expanded(
          child: TabBarView(
            controller: _tabs,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              SocialWebView(
                url: 'https://m.youtube.com',
                onSend: widget.onSendToDownloader,
              ),
              SocialWebView(
                url: 'https://m.facebook.com',
                onSend: widget.onSendToDownloader,
              ),
              SocialWebView(
                url: 'https://www.tiktok.com',
                onSend: widget.onSendToDownloader,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class SocialWebView extends StatefulWidget {
  final String url;
  final ValueChanged<String> onSend;
  const SocialWebView({super.key, required this.url, required this.onSend});

  @override
  State<SocialWebView> createState() => _SocialWebViewState();
}

class _SocialWebViewState extends State<SocialWebView>
    with AutomaticKeepAliveClientMixin {
  late final WebViewController _controller;
  int _progress = 0;
  String? _error;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (p) {
            if (mounted) setState(() => _progress = p);
          },
          onPageStarted: (_) {
            if (mounted) setState(() => _error = null);
          },
          onWebResourceError: (e) {
            if (mounted && e.isForMainFrame == true) {
              setState(() => _error = e.description);
            }
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  Future<void> _send() async {
    try {
      final current = await _controller.currentUrl();
      if (current == null || current.isEmpty) {
        if (mounted) toast(context, 'No page loaded yet');
        return;
      }
      widget.onSend(current);
    } catch (e) {
      if (mounted) toast(context, 'Could not read page link: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      children: [
        if (_progress < 100) LinearProgressIndicator(value: _progress / 100),
        Expanded(
          child: Stack(
            children: [
              WebViewWidget(controller: _controller),
              if (_error != null)
                Container(
                  color: kBackground,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.wifi_off, size: 48, color: Colors.white54),
                      const SizedBox(height: 12),
                      Text(_error!, textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      FilledButton(
                        onPressed: () => _controller.reload(),
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        Container(
          color: kSurface,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () async {
                  try {
                    if (await _controller.canGoBack()) {
                      await _controller.goBack();
                    }
                  } catch (_) {}
                },
              ),
              IconButton(
                icon: const Icon(Icons.arrow_forward),
                onPressed: () async {
                  try {
                    if (await _controller.canGoForward()) {
                      await _controller.goForward();
                    }
                  } catch (_) {}
                },
              ),
              IconButton(
                icon: const Icon(Icons.refresh),
                onPressed: () => _controller.reload(),
              ),
              IconButton(
                icon: const Icon(Icons.download_for_offline, color: kAccent),
                tooltip: 'Send link to Downloader',
                onPressed: _send,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────── Tab 3: Downloader ───────────────────────

class DownloadException implements Exception {
  final String message;
  DownloadException(this.message);
  @override
  String toString() => message;
}

class DownloadTask {
  final String link;
  final bool audio;
  String name;
  double progress = 0;
  String status = 'Queued';
  bool done = false;
  bool failed = false;
  bool cancelled = false;
  String? path;

  DownloadTask(this.link, this.audio) : name = link;

  bool get running => !done && !failed;
}

class DownloaderTab extends StatefulWidget {
  final ValueNotifier<String> sharedLink;
  const DownloaderTab({super.key, required this.sharedLink});

  @override
  State<DownloaderTab> createState() => _DownloaderTabState();
}

class _DownloaderTabState extends State<DownloaderTab> {
  final TextEditingController _link = TextEditingController();
  final List<DownloadTask> _tasks = [];
  bool _audio = false;

  @override
  void initState() {
    super.initState();
    widget.sharedLink.addListener(_onShared);
  }

  void _onShared() {
    if (!mounted) return;
    _link.text = widget.sharedLink.value;
  }

  @override
  void dispose() {
    widget.sharedLink.removeListener(_onShared);
    _link.dispose();
    for (final t in _tasks) {
      t.cancelled = true;
    }
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _paste() async {
    try {
      final data = await Clipboard.getData(Clipboard.kTextPlain);
      final text = data?.text?.trim();
      if (text == null || text.isEmpty) {
        if (mounted) toast(context, 'Clipboard is empty');
        return;
      }
      _link.text = text;
    } catch (e) {
      if (mounted) toast(context, 'Paste failed: $e');
    }
  }

  Future<String> _resolve(String link, bool audio) async {
    final uri = Uri.parse(link);
    final ext = extOf(uri.path);
    if (ext != null && (kAudioExts.contains(ext) || kVideoExts.contains(ext))) {
      return link;
    }
    if (kResolverEndpoint.isEmpty) {
      throw DownloadException(
        'Social links need a resolver backend (set kResolverEndpoint). '
        'Direct .mp4/.mp3 links work as-is.',
      );
    }
    final response = await http
        .post(
          Uri.parse(kResolverEndpoint),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'url': link, 'format': audio ? 'mp3' : 'mp4'}),
        )
        .timeout(const Duration(seconds: 30));
    if (response.statusCode != 200) {
      throw DownloadException('Resolver error (${response.statusCode})');
    }
    final data = jsonDecode(response.body);
    final direct = data is Map ? data['url'] : null;
    if (direct is! String || Uri.tryParse(direct)?.hasScheme != true) {
      throw DownloadException('Resolver returned no valid media link');
    }
    return direct;
  }

  String _sanitize(String input) =>
      input.replaceAll(RegExp(r'[^\w\-. ]'), '_').trim();

  Future<void> _start() async {
    final link = _link.text.trim();
    final uri = Uri.tryParse(link);
    if (uri == null ||
        uri.host.isEmpty ||
        !(uri.scheme == 'http' || uri.scheme == 'https')) {
      toast(context, 'Enter a valid http/https link');
      return;
    }
    await requestStoragePermission();
    final task = DownloadTask(link, _audio);
    setState(() => _tasks.insert(0, task));
    await _run(task);
  }

  Future<void> _run(DownloadTask t) async {
    http.Client? client;
    IOSink? sink;
    File? file;
    try {
      t.status = 'Resolving…';
      _refresh();
      final direct = await _resolve(t.link, t.audio);
      final directUri = Uri.parse(direct);

      final dir = await AppPaths.downloadDir();
      final srcExt = extOf(directUri.path);
      final ext = srcExt ?? (t.audio ? 'mp3' : 'mp4');
      var base = directUri.pathSegments.isNotEmpty
          ? _sanitize(directUri.pathSegments.last)
          : '';
      if (base.toLowerCase().endsWith('.$ext')) {
        base = base.substring(0, base.length - ext.length - 1);
      }
      if (base.isEmpty) {
        base = '${kBrand}_${DateTime.now().millisecondsSinceEpoch}';
      }
      file = File('${dir.path}/$base.$ext');
      if (await file.exists()) {
        file = File(
            '${dir.path}/${base}_${DateTime.now().millisecondsSinceEpoch}.$ext');
      }
      t.name = fileName(file.path);

      client = http.Client();
      final request = http.Request('GET', directUri)
        ..headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 13) $kBrand';
      final response =
          await client.send(request).timeout(const Duration(seconds: 30));
      if (response.statusCode != 200) {
        throw DownloadException('Server returned ${response.statusCode}');
      }

      final total = response.contentLength ?? 0;
      var received = 0;
      sink = file.openWrite();
      t.status = 'Downloading…';
      await for (final chunk in response.stream) {
        if (t.cancelled) throw DownloadException('Cancelled');
        sink.add(chunk);
        received += chunk.length;
        if (total > 0) t.progress = received / total;
        t.status = total > 0
            ? '${formatBytes(received)} / ${formatBytes(total)}'
            : formatBytes(received);
        _refresh();
      }
      await sink.flush();
      await sink.close();
      sink = null;

      t.done = true;
      t.progress = 1;
      t.path = file.path;
      t.status = (t.audio && kVideoExts.contains(ext))
          ? 'Saved as .$ext (source is video; no on-device MP3 conversion)'
          : 'Saved to ${dir.path}';
    } on DownloadException catch (e) {
      t.failed = true;
      t.status = e.message;
    } on TimeoutException {
      t.failed = true;
      t.status = 'Connection timed out';
    } on SocketException {
      t.failed = true;
      t.status = 'No internet connection';
    } on FileSystemException catch (e) {
      t.failed = true;
      t.status = 'File error: ${e.message}';
    } on FormatException {
      t.failed = true;
      t.status = 'Invalid link or response';
    } catch (e) {
      t.failed = true;
      t.status = 'Failed: $e';
    } finally {
      client?.close();
      try {
        await sink?.close();
      } catch (_) {}
      if (t.failed && file != null) {
        try {
          if (await file.exists()) await file.delete();
        } catch (_) {}
      }
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(
          controller: _link,
          keyboardType: TextInputType.url,
          decoration: InputDecoration(
            hintText: 'Paste video / audio link',
            prefixIcon: const Icon(Icons.link),
            suffixIcon: IconButton(
              icon: const Icon(Icons.content_paste),
              onPressed: _paste,
            ),
          ),
        ),
        const SizedBox(height: 14),
        SegmentedButton<bool>(
          segments: const [
            ButtonSegment(
              value: false,
              icon: Icon(Icons.videocam),
              label: Text('MP4 Video'),
            ),
            ButtonSegment(
              value: true,
              icon: Icon(Icons.audiotrack),
              label: Text('MP3 Audio'),
            ),
          ],
          selected: {_audio},
          onSelectionChanged: (s) => setState(() => _audio = s.first),
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(50),
            backgroundColor: kAccent,
          ),
          onPressed: _start,
          icon: const Icon(Icons.download),
          label: const Text('Download to OsmanG7 folder'),
        ),
        const SizedBox(height: 20),
        if (_tasks.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 40),
            child: Center(
              child: Text('No downloads yet',
                  style: TextStyle(color: Colors.white54)),
            ),
          ),
        for (final t in _tasks)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        t.failed
                            ? Icons.error_outline
                            : t.done
                                ? Icons.check_circle
                                : t.audio
                                    ? Icons.audiotrack
                                    : Icons.videocam,
                        color: t.failed
                            ? Colors.redAccent
                            : t.done
                                ? Colors.greenAccent
                                : kAccent,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(t.name,
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                      ),
                      if (t.running)
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => setState(() => t.cancelled = true),
                        )
                      else
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => setState(() => _tasks.remove(t)),
                        ),
                    ],
                  ),
                  if (t.running) ...[
                    const SizedBox(height: 6),
                    LinearProgressIndicator(
                      value: t.progress > 0 ? t.progress : null,
                    ),
                  ],
                  const SizedBox(height: 6),
                  Text(t.status,
                      style: const TextStyle(
                          color: Colors.white60, fontSize: 12)),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

// ─────────────────────────────── Tab 4: Security Vault ───────────────────

enum VerifyResult { ok, wrong, locked }

class VaultStore {
  static const int pinLength = 6;
  static const int maxFails = 5;
  static const int lockSeconds = 60;

  static Future<File> _cfgFile() async {
    final d = await getApplicationSupportDirectory();
    return File('${d.path}/vault.cfg');
  }

  static Future<Directory> filesDir() async {
    final d = await getApplicationSupportDirectory();
    final dir = Directory('${d.path}/vault_files');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static Future<Map<String, dynamic>> _read() async {
    try {
      final f = await _cfgFile();
      if (!await f.exists()) return {};
      final decoded = jsonDecode(await f.readAsString());
      return decoded is Map<String, dynamic> ? decoded : {};
    } catch (_) {
      return {};
    }
  }

  static Future<void> _write(Map<String, dynamic> m) async {
    final f = await _cfgFile();
    await f.writeAsString(jsonEncode(m), flush: true);
  }

  static String _hash(String pin, String salt) =>
      sha256.convert(utf8.encode('$salt:$pin')).toString();

  static Future<bool> hasPin() async => (await _read())['hash'] is String;

  static Future<void> setPin(String pin) async {
    final rnd = Random.secure();
    final salt =
        base64Url.encode(List<int>.generate(16, (_) => rnd.nextInt(256)));
    await _write({
      'salt': salt,
      'hash': _hash(pin, salt),
      'fails': 0,
      'lockUntil': 0,
    });
  }

  static Future<int> lockRemaining() async {
    final cfg = await _read();
    final until = (cfg['lockUntil'] as int?) ?? 0;
    final left = until - DateTime.now().millisecondsSinceEpoch;
    return left > 0 ? (left / 1000).ceil() : 0;
  }

  static Future<VerifyResult> verify(String pin) async {
    final cfg = await _read();
    final salt = cfg['salt'] as String?;
    final hash = cfg['hash'] as String?;
    if (salt == null || hash == null) return VerifyResult.wrong;
    if (await lockRemaining() > 0) return VerifyResult.locked;

    final candidate = _hash(pin, salt);
    var diff = candidate.length ^ hash.length;
    for (var i = 0; i < min(candidate.length, hash.length); i++) {
      diff |= candidate.codeUnitAt(i) ^ hash.codeUnitAt(i);
    }
    if (diff == 0) {
      cfg['fails'] = 0;
      cfg['lockUntil'] = 0;
      await _write(cfg);
      return VerifyResult.ok;
    }
    var fails = ((cfg['fails'] as int?) ?? 0) + 1;
    if (fails >= maxFails) {
      cfg['lockUntil'] = DateTime.now()
          .add(const Duration(seconds: lockSeconds))
          .millisecondsSinceEpoch;
      fails = 0;
    }
    cfg['fails'] = fails;
    await _write(cfg);
    return VerifyResult.wrong;
  }
}

class VaultTab extends StatefulWidget {
  const VaultTab({super.key});

  @override
  State<VaultTab> createState() => VaultTabState();
}

class VaultTabState extends State<VaultTab> with WidgetsBindingObserver {
  final LocalAuthentication _auth = LocalAuthentication();
  bool _loading = true;
  bool _hasPin = false;
  bool _unlocked = false;
  bool _busy = false;
  bool _bioAvailable = false;
  String _entry = '';
  String? _firstPin;
  String _message = '';
  List<File> _files = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      lock();
    }
  }

  void lock() {
    if (!mounted) return;
    if (_unlocked || _entry.isNotEmpty) {
      setState(() {
        _unlocked = false;
        _entry = '';
        _files = [];
        _message = '';
      });
    }
  }

  Future<void> _init() async {
    try {
      final has = await VaultStore.hasPin();
      var bio = false;
      try {
        bio = await _auth.isDeviceSupported() && await _auth.canCheckBiometrics;
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _hasPin = has;
        _bioAvailable = bio;
        _loading = false;
        _message = has ? 'Enter your PIN' : 'Create a 6-digit PIN';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _message = 'Vault error: $e';
      });
    }
  }

  void _digit(String d) {
    if (_busy || _entry.length >= VaultStore.pinLength) return;
    setState(() => _entry += d);
    if (_entry.length == VaultStore.pinLength) _submit();
  }

  void _backspace() {
    if (_busy || _entry.isEmpty) return;
    setState(() => _entry = _entry.substring(0, _entry.length - 1));
  }

  Future<void> _submit() async {
    _busy = true;
    try {
      if (!_hasPin) {
        if (_firstPin == null) {
          setState(() {
            _firstPin = _entry;
            _entry = '';
            _message = 'Confirm your PIN';
          });
        } else if (_firstPin == _entry) {
          await VaultStore.setPin(_entry);
          _hasPin = true;
          _firstPin = null;
          await _unlock();
        } else {
          HapticFeedback.heavyImpact();
          setState(() {
            _firstPin = null;
            _entry = '';
            _message = 'PINs did not match. Start again';
          });
        }
      } else {
        final result = await VaultStore.verify(_entry);
        if (result == VerifyResult.ok) {
          await _unlock();
        } else if (result == VerifyResult.locked) {
          final left = await VaultStore.lockRemaining();
          HapticFeedback.heavyImpact();
          if (mounted) {
            setState(() {
              _entry = '';
              _message = 'Too many attempts. Wait ${left}s';
            });
          }
        } else {
          final left = await VaultStore.lockRemaining();
          HapticFeedback.heavyImpact();
          if (mounted) {
            setState(() {
              _entry = '';
              _message = left > 0
                  ? 'Too many attempts. Wait ${left}s'
                  : 'Wrong PIN';
            });
          }
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _entry = '';
          _message = 'Error: $e';
        });
      }
    } finally {
      _busy = false;
    }
  }

  Future<void> _biometric() async {
    if (_busy) return;
    try {
      final ok = await _auth.authenticate(
        localizedReason: 'Unlock the $kBrand vault',
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );
      if (ok) await _unlock();
    } on PlatformException catch (e) {
      if (mounted) toast(context, 'Biometric unavailable: ${e.message ?? e.code}');
    } catch (e) {
      if (mounted) toast(context, 'Biometric error: $e');
    }
  }

  Future<void> _unlock() async {
    final files = await _loadFiles();
    if (!mounted) return;
    setState(() {
      _unlocked = true;
      _entry = '';
      _message = '';
      _files = files;
    });
  }

  Future<List<File>> _loadFiles() async {
    try {
      final dir = await VaultStore.filesDir();
      final list = await dir.list().where((e) => e is File).toList();
      final files = list.cast<File>();
      files.sort((a, b) => fileName(a.path).compareTo(fileName(b.path)));
      return files;
    } catch (_) {
      return [];
    }
  }

  Future<void> _addFiles() async {
    try {
      final picked = await FilePicker.platform.pickFiles(allowMultiple: true);
      if (picked == null || picked.files.isEmpty) return;
      final dir = await VaultStore.filesDir();
      var count = 0;
      for (final pf in picked.files) {
        final path = pf.path;
        if (path == null) continue;
        try {
          final dest =
              '${dir.path}/${DateTime.now().millisecondsSinceEpoch}_${fileName(path)}';
          await File(path).copy(dest);
          count++;
        } catch (e) {
          debugPrint('Vault copy failed: $e');
        }
      }
      final files = await _loadFiles();
      if (!mounted) return;
      setState(() => _files = files);
      toast(context, 'Added $count file(s) to the vault');
    } catch (e) {
      if (mounted) toast(context, 'Could not add files: $e');
    }
  }

  String _displayName(File f) {
    final name = fileName(f.path);
    final i = name.indexOf('_');
    return i > 0 && int.tryParse(name.substring(0, i)) != null
        ? name.substring(i + 1)
        : name;
  }

  Future<void> _restore(File f) async {
    try {
      final base = await AppPaths.downloadDir();
      final out = Directory('${base.path}/Restored');
      if (!await out.exists()) await out.create(recursive: true);
      await f.copy('${out.path}/${_displayName(f)}');
      await f.delete();
      final files = await _loadFiles();
      if (!mounted) return;
      setState(() => _files = files);
      toast(context, 'Restored to ${out.path}');
    } catch (e) {
      if (mounted) toast(context, 'Restore failed: $e');
    }
  }

  Future<void> _remove(File f) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete permanently?'),
        content: Text(_displayName(f)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await f.delete();
      if (!mounted) return;
      setState(() => _files.remove(f));
    } catch (e) {
      if (mounted) toast(context, 'Delete failed: $e');
    }
  }

  Future<void> _changePin() async {
    final oldCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    final result = await showDialog<List<String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Change PIN'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: oldCtrl,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: VaultStore.pinLength,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'Current PIN'),
            ),
            TextField(
              controller: newCtrl,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: VaultStore.pinLength,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'New PIN'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, [oldCtrl.text, newCtrl.text]),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    oldCtrl.dispose();
    newCtrl.dispose();
    if (result == null || !mounted) return;
    try {
      if (result[1].length != VaultStore.pinLength) {
        toast(context, 'New PIN must be ${VaultStore.pinLength} digits');
        return;
      }
      final check = await VaultStore.verify(result[0]);
      if (check != VerifyResult.ok) {
        if (mounted) toast(context, 'Current PIN is incorrect');
        return;
      }
      await VaultStore.setPin(result[1]);
      if (mounted) toast(context, 'PIN updated');
    } catch (e) {
      if (mounted) toast(context, 'Could not change PIN: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return _unlocked ? _buildVault() : _buildLock();
  }

  Widget _buildLock() {
    return SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: kAccent.withAlpha(40),
                ),
                child: const Icon(Icons.shield_moon, size: 44, color: kAccent),
              ),
              const SizedBox(height: 14),
              const Text(
                kBrand,
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                ),
              ),
              const Text(
                'Private Vault · Owner: $kBrand',
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
              const SizedBox(height: 24),
              Text(_message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(VaultStore.pinLength, (i) {
                  final filled = i < _entry.length;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 7),
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: filled ? kAccent : Colors.transparent,
                      border: Border.all(color: kAccent, width: 1.5),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 24),
              _buildPad(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPad() {
    Widget key(String label, {VoidCallback? onTap, IconData? icon}) {
      return Padding(
        padding: const EdgeInsets.all(6),
        child: SizedBox(
          width: 72,
          height: 72,
          child: onTap == null
              ? const SizedBox.shrink()
              : Material(
                  color: kSurface,
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: onTap,
                    child: Center(
                      child: icon != null
                          ? Icon(icon)
                          : Text(label,
                              style: const TextStyle(
                                  fontSize: 24, fontWeight: FontWeight.w600)),
                    ),
                  ),
                ),
        ),
      );
    }

    Widget row(List<Widget> children) =>
        Row(mainAxisSize: MainAxisSize.min, children: children);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final r in [
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
        ])
          row([for (final d in r) key(d, onTap: () => _digit(d))]),
        row([
          key('',
              icon: Icons.fingerprint,
              onTap: (_bioAvailable && _hasPin) ? _biometric : null),
          key('0', onTap: () => _digit('0')),
          key('', icon: Icons.backspace_outlined, onTap: _backspace),
        ]),
      ],
    );
  }

  Widget _buildVault() {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: kAccent,
        onPressed: _addFiles,
        icon: const Icon(Icons.add),
        label: const Text('Add files'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
            child: Row(
              children: [
                const Icon(Icons.lock_open, color: Colors.greenAccent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text('Vault unlocked · ${_files.length} file(s)'),
                ),
                IconButton(
                  icon: const Icon(Icons.password),
                  tooltip: 'Change PIN',
                  onPressed: _changePin,
                ),
                IconButton(
                  icon: const Icon(Icons.lock),
                  tooltip: 'Lock now',
                  onPressed: lock,
                ),
              ],
            ),
          ),
          Expanded(
            child: _files.isEmpty
                ? const Center(
                    child: Text('Your vault is empty',
                        style: TextStyle(color: Colors.white54)),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
                    itemCount: _files.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) {
                      final f = _files[i];
                      int size = 0;
                      try {
                        size = f.lengthSync();
                      } catch (_) {}
                      return AppCard(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        child: Row(
                          children: [
                            const Icon(Icons.insert_drive_file, color: kAccent),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(_displayName(f),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis),
                                  Text(formatBytes(size),
                                      style: const TextStyle(
                                          color: Colors.white54,
                                          fontSize: 12)),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.unarchive_outlined),
                              tooltip: 'Restore',
                              onPressed: () => _restore(f),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline),
                              tooltip: 'Delete',
                              onPressed: () => _remove(f),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
