import re, sys, pathlib

root = pathlib.Path(sys.argv[1])

# 1) AndroidManifest: permissions, label, legacy storage
manifest = root / "android/app/src/main/AndroidManifest.xml"
text = manifest.read_text()
perms = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
    <uses-permission android:name="android.permission.USE_BIOMETRIC"/>
"""
if "MANAGE_EXTERNAL_STORAGE" not in text:
    text = re.sub(r"(<manifest[^>]*>)", r"\1" + perms, text, count=1)
text = text.replace("<application", '<application android:requestLegacyExternalStorage="true"', 1)
text = re.sub(r'android:label="[^"]*"', 'android:label="OsmanG7"', text, count=1)
manifest.write_text(text)

# 2) MainActivity -> FlutterFragmentActivity (needed by local_auth)
for kt in (root / "android/app/src/main").rglob("MainActivity.kt"):
    pkg = re.search(r"^package\s+(\S+)", kt.read_text(), re.M).group(1)
    kt.write_text(
        f"package {pkg}\n\n"
        "import io.flutter.embedding.android.FlutterFragmentActivity\n\n"
        "class MainActivity : FlutterFragmentActivity()\n"
    )

# 3) minSdk 24
for name in ("build.gradle.kts", "build.gradle"):
    f = root / "android/app" / name
    if f.exists():
        s = f.read_text()
        s = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 24", s)
        s = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 24", s)
        f.write_text(s)

print("Android project patched.")
