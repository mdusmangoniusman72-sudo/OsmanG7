OsmanG7 - build the APK (no PC needed)

1. Create a new GitHub repository and upload everything from this zip
   (keep the .github folder, lib, tools and pubspec.yaml as they are).
2. Open the repo > Actions > "Build OsmanG7 APK" > Run workflow.
3. When it finishes (about 5-10 minutes), open the run and download the
   artifact "OsmanG7-apk". Unzip it to get app-release.apk.
4. Copy app-release.apk to your phone and install it
   (allow "Install unknown apps" when asked).

Local build on a PC with Flutter installed:
   flutter create --org com.osmang7 --project-name osmang7 --platforms android build_app
   copy lib/main.dart and pubspec.yaml into build_app
   python3 tools/patch_android.py build_app
   cd build_app && flutter pub get && flutter build apk --release
